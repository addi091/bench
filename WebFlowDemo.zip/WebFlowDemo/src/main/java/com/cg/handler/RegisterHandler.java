/**
 * 
 */
package com.cg.handler;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.cg.entity.Address;
import com.cg.entity.Login;
import com.cg.entity.User;
import com.cg.model.RegisterModel;

/**
 * @author Aditya Sinha
 *
 */
@Component
public class RegisterHandler {
	Map<User, String> userMap = new HashMap<User, String>();
	
	public RegisterModel init() {
		
		return new RegisterModel();
	}
	
	public void addUser(RegisterModel registerModel, User user) {
		registerModel.setUser(user);
		userMap.put(user, "user");
		System.out.println(userMap);
	}
	
	public void addBill(RegisterModel registerModel, Address billing) {
		registerModel.setBilling(billing);
		
	}
	public void displayList () {
		
	}
	public String validation(Login login) {
		String id = login.getUserId();
		String pass = login.getPassword();
		if(id.equals("adi@gmail.com") && pass.equals("password") ) {
			return "true";
		}
		else {
			return "false";
		}
	}
	
}
