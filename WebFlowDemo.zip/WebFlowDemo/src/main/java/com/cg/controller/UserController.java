/**
 * 
 */
package com.cg.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @author Aditya Sinha
 * 
 * This is the controller class
 *
 */


@Controller
public class UserController {
	
//UserServiceImpl service = new UserServiceImpl();
	
	@RequestMapping(value = "/")
	public String sayHello() {
		return "home";
	}

	// having same mapping as our flow id
	@RequestMapping(value = "/registers")
	public String register() {
		return "signup-personal";
	}
	
	@RequestMapping(value = "/personal")
	public String personal() {
		return "signup-personal";
	}
	@RequestMapping(value = "/loginView")
	public String login() {
		return "loginpage";
	}
	
//	@RequestMapping(value = "/add")
//	public ModelAndView display(@ModelAttribute("user") User user, Model model) {
//         
//		model.addAttribute("firstName", user.getFirstName());
//		model.addAttribute("lastName", user.getLastName());
//		model.addAttribute("gender", user.getGender());
//		model.addAttribute("age", user.getAge());
//		
//		service.display(user);
//		
//		ModelAndView mv = new ModelAndView();
//		mv.setViewName("display");
//		mv.addObject(user);
//		return mv;
//	}
	
}
