/**
 * 
 */
package com.cg.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.entity.User;
/**
 * @author Aditya Sinha
 * 
 * This is the controller class
 *
 */
import com.cg.service.UserServiceImpl;

@Controller
public class UserController {
	
UserServiceImpl service = new UserServiceImpl();
	
	@RequestMapping(value = "/")
	public String sayHello() {
		return "home";
	}

	// having same mapping as our flow id
	@RequestMapping(value = "/register")
	public String register() {
		return "signup-personal";
	}
	
	@RequestMapping(value = "/login")
	public String login() {
		return "login";
	}
	@RequestMapping(value = "/personal")
	public String personal() {
		return "signup-personal";
	}
	
	@RequestMapping(value = "/add")
	public ModelAndView display(@ModelAttribute("user") User user, Model model) {
         
		model.addAttribute("firstName", user.getFirstName());
		model.addAttribute("lastName", user.getLastName());
		model.addAttribute("gender", user.getGender());
		model.addAttribute("age", user.getAge());
		
		service.display(user);
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("display");
		mv.addObject(user);
		return mv;
	}
	
}
