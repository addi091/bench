/**
 * 
 */
package com.cg.service;

import com.cg.entity.User;

/**
 * @author Aditya Sinha
 *
 */
public interface UserService {

	public User display(User user);
}
