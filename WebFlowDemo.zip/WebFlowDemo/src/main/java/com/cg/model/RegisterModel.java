/**
 * 
 */
package com.cg.model;

import java.io.Serializable;

import com.cg.entity.Address;
import com.cg.entity.Login;
import com.cg.entity.User;

/**
 * @author Aditya Sinha
 *
 */
public class RegisterModel implements Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private User user;
	
	private Address billing;
	
	private Login login;

	public Login getLogin() {
		return login;
	}

	public void setLogin(Login login) {
		this.login = login;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Address getBilling() {
		return billing;
	}

	public void setBilling(Address billing) {
		this.billing = billing;
	}
	
	
}
