import { Component, OnInit } from '@angular/core';
import { Contract } from 'src/model/contracts';
import { ServiceService } from '../service.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  ID: any;
  data: Contract[] = [];
  constructor(private serviceService: ServiceService, private route: ActivatedRoute) { }

  ngOnInit() {
    // this.getById();
  }
  getById() {
    this.ID = this.route.snapshot.params['ID'];
    console.log(this.ID);
    this.serviceService.detailsById(this.ID).subscribe(cont => {
    this.data = cont;
    JSON.stringify(this.data);
    console.log(this.data);
    });
  }
  logout() {
    sessionStorage.setItem('isLoggedIn', 'false');
    sessionStorage.removeItem('userId');
    sessionStorage.removeItem('password');
    console.log(sessionStorage);
    alert('You are sucessfully logged out');
  }
}
