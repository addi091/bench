import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { InfoComponent } from './info/info.component';
import { HomeComponent } from './home/home.component';
import { ViewComponent } from './view/view.component';
import { EditComponent } from './edit/edit.component';

const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'home', component: HomeComponent,  data: {title: 'Welcome to Home Page..!'}},
  { path: 'register', component: RegisterComponent,  data: {title: 'Welcome to Register Page..!'} },
  { path: 'login', component: LoginComponent,  data: {title: 'Welcome to Login Page..!'} },
  { path: 'info', component: InfoComponent,  data: {title: 'Welcome to List Page..!'} },
  { path: 'view', component: ViewComponent,  data: {title: 'Welcome to View Page..!'} },
  { path: 'edit', component: EditComponent,  data: {title: 'Welcome to Edit Page..!'} }
];
@NgModule({
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
