import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Contract } from 'src/model/contracts';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  baseHref = 'http://localhost:3000/contract';
  baseHref1 = 'http://localhost:3000/contract?ID=ba6aef67a9';
  contract: Contract[] = [];


  constructor(private http: HttpClient) { }

  details(): Observable<Contract[]> {
    return this.http.get<Contract[]>(this.baseHref);

  }

  detailsById(ID): Observable<Contract[]> {
  return this.http.get<Contract[]>(this.baseHref1);
  }


}
