import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Login } from 'src/model/login';
import { FormControl, Validators, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  login: Login;
  loggedInStatus: false;
  userId: any;
  password: any;
  // userControl = new FormControl('', [Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$')]);



  constructor(private router: Router) {
    this.login = new Login();
    this.userId = this.login.userId;
    this.password = this.login.password;
  }

  ngOnInit() {
  }
  storeCredentials() {
    if ((this.userId === undefined) || (this.password === undefined)) {
      alert('Username and Password cannot be empty');

    // if (this.userId !== this.userControl) {
    //   alert('username should match the requirement');
     }
    else {
    sessionStorage.setItem('userId', this.userId);
    sessionStorage.setItem('password', this.password);
    sessionStorage.setItem('isLoggedIn', 'true');
    console.log(sessionStorage);
    this.router.navigate(['/info']);
  }
  }
}

