import { Component, OnInit } from '@angular/core';
import { Contract } from 'src/model/contracts';
import { ServiceService } from '../service.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {

  ID: any;
  data: Contract[] = [];
  constructor(private serviceService: ServiceService, private route: ActivatedRoute) { }

  ngOnInit() {
    this.getById();

  }
  getById() {
    this.ID = this.route.snapshot.params['ID'];
    console.log(this.ID);
    this.serviceService.detailsById(this.ID).subscribe(cont => {
    this.data = cont;
    JSON.stringify(this.data);

    });
  }
  logout() {
    sessionStorage.setItem('isLoggedIn', 'false');
    sessionStorage.removeItem('userId');
    sessionStorage.removeItem('password');
    console.log(sessionStorage);
    alert('You are sucessfully logged out');
  }
}
