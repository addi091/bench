import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { Router } from '@angular/router';
import { Contract } from 'src/model/contracts';
import { MatTableDataSource, PageEvent, MatPaginator } from '@angular/material';
import { ViewChild } from '@angular/core';

@Component ({
  selector: 'app-info',
  templateUrl: './info.component.html',
  styleUrls: ['./info.component.css']
})
export class InfoComponent implements OnInit {
  [x: string]: any;
  searchTerm: string;
  // demo = require('db.json');
  contractsArr: Contract[] = [];

  displayColumns = [
    'ID', 'NUMEROPRATICA', 'SERVIZIO', 'OPERATORE', 'CF_PIVA', 'STATO_CONTRATTO',
    'DATA_INIZIO_CONVENZIONE', 'ACTIONS'
  ];
  dataSource;
   @ViewChild(MatPaginator) paginator: MatPaginator;
  constructor(private serviceService: ServiceService, private router: Router) {

  }

  ngOnInit() {
    this.get();
  }
  get() {
    this.serviceService.details().subscribe(cont => {
    this.contractsArr = cont;
    JSON.stringify(this.contractsArr);
    console.log(this.contractsArr);
    this.dataSource = new MatTableDataSource(this.contractsArr);
    this.dataSource.paginator = this.paginator;
    });
  }
delete() {
  alert('Successfully Deleted');
}
logout() {
  sessionStorage.setItem('isLoggedIn', 'false');
  sessionStorage.removeItem('userId');
  sessionStorage.removeItem('password');
  console.log(sessionStorage);
  alert('You are sucessfully logged out');
}
doFilter = (value: string) => {
  this.dataSource.filter = value.trim().toLocaleLowerCase();
}

}
