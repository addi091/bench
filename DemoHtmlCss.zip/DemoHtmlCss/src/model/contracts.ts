export class Contract {
  ID: String;
  NUMEROPRATICA: String;
  SERVIZIO: String;
  OPERATORE: String;
  CF_PIVA: String;
  STATO_CONTRATTO: String;
  DATA_INIZIO_CONVENZIONE: String;
}
