// tslint:disable-next-line: class-name
export class editbook{
  isbn: number;
  bookTitle: String;
  publishingYear: String;
  noOfCopiesActual: number;
  noOfCopiesCurrent: number;


}
