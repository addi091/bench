export class admin{
    id: number;
    firstName: String;
    lastName: String;
    
}