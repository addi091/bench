import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BookComponent } from './book/book.component';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { MagazineComponent } from './magazine/magazine.component';
import { DvdComponent } from './dvd/dvd.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { LmsMaterialModule } from './material.module.1';
import { HomeComponent } from './home/home.component';
import { AdminComponent } from './admin/admin.component';
import { EditBookComponent } from './edit-book/edit-book.component';
import { StudentComponent } from './student/student.component';
import { AddBookComponent } from './add-book/add-book.component';
import { SearchBookComponent } from './search-book/search-book.component';





@NgModule({
  declarations: [
    AppComponent,
    BookComponent,
    RegisterComponent,
    LoginComponent,
    MagazineComponent,
    DvdComponent,
    HomeComponent,
    AdminComponent,
    EditBookComponent,
    StudentComponent,
    AddBookComponent,
    SearchBookComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    LmsMaterialModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule


  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
