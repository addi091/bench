import { Component, OnInit, Input, ViewChild } from "@angular/core";
import { FormControl, Validators, Form, FormGroup } from "@angular/forms";
import { Registration } from "../model/registration";
import { ServiceService } from "../service.service";
import * as sha1 from "sha1/sha1";

@Component({
  selector: "app-register",
  templateUrl: "./register.component.html",
  styleUrls: ["./register.component.css"]
})
export class RegisterComponent implements OnInit {
  registration: Registration;
  passwordMatchError = false;
  conversionEncryptOutput: string;
  myForm: FormGroup;
  selectedDate;
  formattedDate;
  // form controls
  //email = new FormControl('', [Validators.required, Validators.email]);
  // employeeId = new FormControl('', [Validators.required, Validators.employeeId]);
  passwordControl = new FormControl('', [Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}')]);
  repeatPasswordControl = new FormControl('', []);

  constructor(private service: ServiceService) {
    this.registration = new Registration();
    this.registration.gender = 'Male';
  }

  ngOnInit() {}
  // getErrorMessage() {
  //   return this.employeeId.hasError('required')
  //     ? 'Email is required'
  //     : this.employeeId.hasError('email')
  //     ? 'Not a valid email'
  //     : '';
  // }
 // validate password and confirm password
  validateboth() {
    if (this.registration.password !== '') {
      if (this.registration.password === this.registration.repeatpassword) {
        // password matches
      } else {
        this.repeatPasswordControl.setErrors(Validators.requiredTrue);
      }
    }
  }
  storeDetails() {
    this.service.registerDetails(this.registration).subscribe(
      data => {
        console.log(data);
      },
      error => {
        console.log(error);
      }
    );
  }
  register() {
    // const momentDate = new Date(this.selectedDate);
    // this.formattedDate = moment(momentDate).format('DD/MM/YYYY');
    // this.registration.dateofbirth = this.formattedDate;
    this.conversionEncryptOutput = sha1(this.registration.password);
    this.registration.password = this.conversionEncryptOutput;
    this.registration.repeatpassword = this.conversionEncryptOutput;
    this.service.registerDetails(this.registration).subscribe(
        result => {
          console.log(result);
        },
        error => {
          console.log(error);
        }
      );
  }
}
