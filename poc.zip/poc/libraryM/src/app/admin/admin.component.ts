import { Component, OnInit, ViewChild } from '@angular/core';
import { ServiceService } from '../service.service';

import { book } from '../model/book';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  [x: string]: any;
  // bookArr: book[] = [];

  constructor(private serviceService: ServiceService) { }

  ngOnInit() {
  }
  navigateToBook(){

    this.router.navigate(['/student']);

  }

}
