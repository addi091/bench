import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { editbook } from '../model/editbook';
import { book } from '../model/book';

@Component({
  selector: 'app-edit-book',
  templateUrl: './edit-book.component.html',
  styleUrls: ['./edit-book.component.css']
})
export class EditBookComponent implements OnInit {
  editbook: editbook;
  constructor(private serviceService : ServiceService) {
    this.editbook = new editbook();
   }

  ngOnInit() {
  }
  storeDetails() {
    this.serviceService.storeBookDetails(this.editbook);
  }

}
