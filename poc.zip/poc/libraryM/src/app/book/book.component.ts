import { Component, OnInit, ViewChild } from '@angular/core';
import { ServiceService } from '../service.service';
import { book } from '../model/book';
import { Registration } from '../model/registration';
import { editbook } from '../model/editbook';
import { Router } from '@angular/router';
import { MatTableDataSource } from '@angular/material';



@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.css']
})
export class BookComponent implements OnInit {
  [x: string]: any;
  displayedColumns = ['isbn', 'bookTitle', 'publishingYear', 'noOfCopiesActual', 'noOfCopiesCurrent', 'actions'];
  dataSource;
  registeredDetails: Registration;
  bookToEdit: editbook;
  isEditing: boolean;
  bookArr: book[] = [];
  constructor(private serviceService: ServiceService, private router: Router) {
    this.registeredDetails = new Registration();
    // this.book = new book();
   
    
  }

  ngOnInit() {
    this.getAll();

  }
  books: book;
  getAll() {
    console.log(this.bookArr);
    this.serviceService.bookDetails().subscribe(books => {
      this.bookArr = books;
      this.dataSource = new MatTableDataSource(this.bookArr);
    })

  }
  navigateToEdit() {

    this.router.navigate(['/edit-book']);

  }
  deleteAll(isbn) {
    this.serviceService.deleteBook(isbn).subscribe(result => {
      this.book = result;
      console.log(this.book);
      // JSON.parse(localStorage.removeItem("book")["isbn"]);
      this.router.navigate(["/book"]);
    });
    
  }

}
