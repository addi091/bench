import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { book } from '../model/book';
import { MatTableDataSource } from '@angular/material';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  [x: string]: any;
  dataSource;
  bookArr1: book[] = [];
  constructor(private serviceService: ServiceService) {
    this.book = new book();
   }

  ngOnInit() {
  
  }
  books: book;
  // getBook() {
  //   console.log(this.bookArr1);
  //   this.serviceService.searchBook(this.book).subscribe(books => {
  //   this.bookArr1 = books;
  //   this.dataSource = new MatTableDataSource(this.bookArr1);
  //   })

  // }
}
