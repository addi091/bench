import { Injectable } from "@angular/core";
import { Registration } from "./model/registration";
import { Login } from "./model/login";
import { Router } from "@angular/router";
import { HttpClient } from "@angular/common/http";
import { book } from "./model/book";
import { magazine } from "./model/magazine";
import { dvd } from "./model/dvd";
import { editbook } from "./model/editbook";
import { Observable } from "rxjs";

@Injectable({
  providedIn: "root"
})
export class ServiceService {
  baseHref = "http://localhost:8888";
  public loggedCustomer:Registration=new Registration();
  public isLogged:boolean = false
  constructor(private http: HttpClient, private routes: Router) {}

  postOne(login: Login): Observable<Registration> {
    let id = login.employeeId;
    let pass = login.password;
    return this.http.get<Registration>(this.baseHref + `/employeeById/${id}/${pass}`);
  }
  searchBook(book: book){ 
    let id = book.isbn;
    return this.http.get<book[]>(this.baseHref + `/bookByIsbn/${id}`);
  }
  registerDetails(register: Registration) {
    return this.http.post<Login>(this.baseHref + "/addemployee", register);
  }

  bookDetails() {
    return this.http.get<book[]>(this.baseHref + "/allbooks");
  }
  add(book: book) {
    return this.http.post<book>(this.baseHref + "/addbook", book);
  }
  dvdDetails() {
    return this.http.get<dvd[]>(this.baseHref + "/alldvds");
  }
  magazineDetails() {
    return this.http.get<magazine[]>(this.baseHref + "/allmagazine");
  }
  storeBookDetails(obj: editbook): any {
    // this.recievedBook = obj;
  }
  getBookDetails() {
    // return this.receivedObj;
  }
}
