package com.capgemini.service;

import java.util.List;

import com.capgemini.bean.BookDetails;
import com.capgemini.bean.EmployeeDetails;

public interface EmployeeService {
	public EmployeeDetails addEmployee(EmployeeDetails employee);
	
	public List<EmployeeDetails> employeeList();
	
	public void deleteEmployee(int id);

	public EmployeeDetails employeeById(int Id);


	EmployeeDetails getByEmployeeIdAndPassword(int id,String pass);





}
