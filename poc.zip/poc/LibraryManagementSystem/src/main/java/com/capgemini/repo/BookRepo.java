package com.capgemini.repo;

import org.springframework.data.repository.CrudRepository;

import com.capgemini.bean.BookDetails;

public interface BookRepo extends CrudRepository<BookDetails, Integer>{

	BookDetails findBookByIsbn(int id);
}
