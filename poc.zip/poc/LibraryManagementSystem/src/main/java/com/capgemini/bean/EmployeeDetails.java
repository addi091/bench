package com.capgemini.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "employee_details")
public class EmployeeDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@Column(name = "employee_id")
	private int employeeId;
	
	@Column(name = "employee_firstname")
	private String firstName;
	
	@Column(name = "employee_lastname")
	private String lastName;
	
	@Column(name = "employee_gender")
	private String gender;
	
	@Column(name = "employee_mbNumber")
	private String mbNumber;
	
	@Column(name = "password")
	private String password;
	
	
	
	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public int getEmployeeId() {
		return employeeId;
	}



	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}



	public String getFirstName() {
		return firstName;
	}



	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}



	public String getLastName() {
		return lastName;
	}



	public void setLastName(String lastName) {
		this.lastName = lastName;
	}



	public String getGender() {
		return gender;
	}



	public void setGender(String gender) {
		this.gender = gender;
	}


	public String getMbNumber() {
		return mbNumber;
	}



	public void setMbNumber(String mbNumber) {
		this.mbNumber = mbNumber;
	}



	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}



	public BorrowerDetails getBorrower() {
		return borrower;
	}



	public void setBorrower(BorrowerDetails borrower) {
		this.borrower = borrower;
	}



	/*************RelationShip*****************/
	@JsonIgnore
	@OneToOne(mappedBy = "employee")
	private BorrowerDetails borrower;
	
}
