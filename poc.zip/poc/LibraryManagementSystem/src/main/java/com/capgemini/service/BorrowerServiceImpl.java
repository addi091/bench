package com.capgemini.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bean.BorrowerDetails;
import com.capgemini.repo.BorrowerRepo;

@Service
@Transactional
public class BorrowerServiceImpl implements BorrowerService {
	
	@Autowired
	BorrowerRepo borrowRepo;

	@Override
	public BorrowerDetails addBorrow(BorrowerDetails borrow) {
		return borrowRepo.save(borrow);
	}
	
	
}
