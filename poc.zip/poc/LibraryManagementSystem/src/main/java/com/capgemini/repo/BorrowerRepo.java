package com.capgemini.repo;

import org.springframework.data.repository.CrudRepository;

import com.capgemini.bean.BookDetails;
import com.capgemini.bean.BorrowerDetails;

public interface BorrowerRepo extends CrudRepository<BorrowerDetails, Integer> {

	
}
