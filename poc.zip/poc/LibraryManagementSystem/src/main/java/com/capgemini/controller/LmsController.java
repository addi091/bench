package com.capgemini.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.bean.BookDetails;
import com.capgemini.bean.BorrowerDetails;
import com.capgemini.bean.EmployeeDetails;
import com.capgemini.service.BookService;
import com.capgemini.service.BorrowerService;
import com.capgemini.service.EmployeeService;

@CrossOrigin("http://localhost:4200")
@RestController
public class LmsController {
	
	@Autowired
	EmployeeService employeeService;
	
	@Autowired
	BookService bookService;
	
	@Autowired
	BorrowerService borrowService;
	
	//employee
	@PostMapping(path = "/addemployee",consumes="application/json",produces="application/json")
	public EmployeeDetails addEmployee(@RequestBody EmployeeDetails emp) {
		return employeeService.addEmployee(emp);
	}
	
	@GetMapping(path = "/allemployees",consumes = "application/json", produces = "application/json")
	public List<EmployeeDetails> employeeList(){
		return employeeService.employeeList();
	}
	
	@GetMapping(path = "/employeeById/{id}/{pass}")
	public EmployeeDetails employeeById(@PathVariable("id")int id , @PathVariable("pass")String pass){
		 EmployeeDetails e = employeeService.getByEmployeeIdAndPassword(id, pass);
		return e;
	}
	
	
	
	@DeleteMapping(path ="/deleteemployee/{id}",consumes = "application/json",produces = "application/json")
	public List<EmployeeDetails> deleteEmployee(@PathVariable int id) {
		employeeService.deleteEmployee(id);
		return employeeService.employeeList();
		
	}
	
	@PutMapping(path= "/updateemployee",consumes = "application/json",produces = "application/json")
	public List<EmployeeDetails> updateEmployee(@RequestBody EmployeeDetails employee){
		employeeService.addEmployee(employee);
		return employeeService.employeeList();
	}
	
	//book
	@PostMapping(path = "/addbook",consumes = "application/json",produces = "application/json")
	public BookDetails addBook(@RequestBody BookDetails book) {
		return bookService.addBook(book);
	}
	
	@GetMapping(path = "/allbooks", produces = "application/json")
	public List<BookDetails> bookList(){
		return bookService.bookList();
	}
	
//	@DeleteMapping(path ="/deletebook/{id}")
//	public List<BookDetails> deleteBook(@PathVariable("id") int id) {
//		bookService.deleteBook(id);
//		return bookService.bookList();
//		
//	}
	
	@DeleteMapping(path ="/deletebook/{isbn}")
	public List<BookDetails> deleteBookByIsbn(@PathVariable("isbn") int isbn) {
		bookService.deleteByIsbn(isbn);
        return bookService.bookList();
		
	}
	@GetMapping(path = "/bookByIsbn/{id}")
	public BookDetails bookByIsbn(@PathVariable("id")int id){
		BookDetails b = bookService.getByIsbn(id);
		return b;
	}
	
	// borrow details
	@PostMapping(path = "/issueBook",consumes = "application/json",produces = "application/json")
	public BorrowerDetails issue(@RequestBody BorrowerDetails borrow) {
		return borrowService.addBorrow(borrow);
	}
	@GetMapping(path = "/getissued")
	public List<BorrowerDetails> issueed() {
		return borrowService.findDetails();
		
		
	}
}
