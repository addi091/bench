package com.capgemini.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "borrower_details")
public class BorrowerDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "borrower_id")
	private int borrowerId;
	
	@Column(name = "borrowed_from_date")
	private  String borrowedFromDate;
	
	@Column(name = "borrowed_to_date")
	private String borrowedToDate;
	
	@Column(name = "actual_return_date")
	private String actualReturnDate;
	
	
	
	
	public int getBorrowerId() {
		return borrowerId;
	}

	public void setBorrowerId(int borrowerId) {
		this.borrowerId = borrowerId;
	}

	public String getBorrowedFromDate() {
		return borrowedFromDate;
	}

	public void setBorrowedFromDate(String borrowedFromDate) {
		this.borrowedFromDate = borrowedFromDate;
	}

	public String getBorrowedToDate() {
		return borrowedToDate;
	}

	public void setBorrowedToDate(String borrowedToDate) {
		this.borrowedToDate = borrowedToDate;
	}

	public String getActualReturnDate() {
		return actualReturnDate;
	}

	public void setActualReturnDate(String actualReturnDate) {
		this.actualReturnDate = actualReturnDate;
	}

	public BookDetails getBook() {
		return book;
	}

	public void setBook(BookDetails book) {
		this.book = book;
	}

	public EmployeeDetails getEmployee() {
		return employee;
	}

	public void setEmployee(EmployeeDetails employee) {
		this.employee = employee;
	}

	/**************Relationship*******************/
	@OneToOne
	@JoinColumn(name = "isbn")
	private BookDetails book;
	
	@OneToOne
	@JoinColumn(name = "employee_id")
	private EmployeeDetails employee;
	
}
