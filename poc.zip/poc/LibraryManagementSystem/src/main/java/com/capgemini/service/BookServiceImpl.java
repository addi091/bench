package com.capgemini.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bean.BookDetails;
import com.capgemini.repo.BookRepo;

@Service
@Transactional
public class BookServiceImpl implements BookService{
	
	@Autowired
	BookRepo bookRepo;

	@Override
	public BookDetails addBook(BookDetails body) {
		
		return bookRepo.save(body);
	}

	@Override
	public List<BookDetails> bookList() {
		return (List<BookDetails>) bookRepo.findAll();
	}

//	@Override
//	public void deleteBook(int id) {
//		bookRepo.deleteById(id);
//	}

	@Override
	public BookDetails getByIsbn(int id) {
		return bookRepo.findBookByIsbn(id);
	}

	@Override
	public void deleteByIsbn(int isbn) {
       bookRepo.deleteById(isbn);
       
	}
}
