package com.capgemini.service;

import com.capgemini.bean.BorrowerDetails;

public interface BorrowerService {
	
	BorrowerDetails addBorrow(BorrowerDetails borrow);

}
