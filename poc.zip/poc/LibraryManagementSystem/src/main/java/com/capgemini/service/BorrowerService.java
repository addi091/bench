package com.capgemini.service;

import java.util.List;

import com.capgemini.bean.BorrowerDetails;

public interface BorrowerService {
	
	BorrowerDetails addBorrow(BorrowerDetails borrow);

	List<BorrowerDetails> findDetails();
}
