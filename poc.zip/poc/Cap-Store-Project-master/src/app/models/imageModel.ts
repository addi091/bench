export class ImageModel{
    public id:number;
    public path:number;
}