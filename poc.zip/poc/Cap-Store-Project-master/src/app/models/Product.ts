import { Inventory } from './InventoryModel';
import { ImageModel } from './imageModel';

export class Product {
    id: number;
    name: string;
    brand:string;
    inventoryFromProduct:Inventory[];
    imageFromProduct:ImageModel[]
}