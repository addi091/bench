import { CheckoutService } from './../services/checkout.service';
import { Cart } from './../models/CartModel';
import { Product } from './../models/Product';
import { CartService } from './../services/cart.service';
import { Component, OnInit } from '@angular/core';
import { ProductService } from '../services/product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {

  constructor(private cartService: CartService,
    public productService:ProductService
    ,public checkOutService:CheckoutService,
    private router:Router
    
    ) { }

  prods: Product[] = []
  carts: Cart = new Cart()
  quantity: number[] = []
  totalPrice:number=0
  selectedType: boolean[] = []
  ngOnInit() {
    this.selectedType[0] = true
    var customerId = JSON.parse(localStorage.getItem("user"))["id"];
    this.cartService.getCart(customerId).subscribe(
      res => {
        console.log(res)
        res.cartProducts.forEach(e => {
          this.prods.push(e["product"]);
          this.quantity.push(e["quantity"]);

          //this.totalPrice = this.totalPrice + (e["product"]["inventoryFromProduct"]["price"] * e["quantity"]);
        })
      }, err => { console.log(err) },()=>{this.merchantFetch()}
    )
  }

  merchantFetch()
  {
    this.productService.getMerchants(this.prods[0].id).subscribe(
      res=>{
        this.prods.forEach( e=>{
            this.totalPrice = this.totalPrice + e.inventoryFromProduct[0].price;
          }
        )
        this.checkOutService.merchantId=res[0].id
        this.checkOutService.totalAmount = this.totalPrice;
      },err=>{console.log(err)}
    )
  }

  setMode(i: number) {
    this.selectedType = [];
    this.selectedType[i] = true;
  }

  checkoutFinal()
  {
    this.checkOutService.placeOrder().subscribe(
      res=>{
        console.log(res)
        this.router.navigate(['/invoice']);
      },err=>{console.log(err)}
    );
  }
}
