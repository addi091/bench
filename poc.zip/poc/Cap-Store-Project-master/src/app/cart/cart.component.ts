import { CheckoutService } from './../services/checkout.service';
import { Component, OnInit } from '@angular/core';
import { Product } from '../models/Product';
import { CartService } from '../services/cart.service';
import { Cart } from '../models/CartModel';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  itemList:Cart=new Cart();
  totalSum:number=0;
  constructor(private cartService:CartService,public checkOutService:CheckoutService) { }

  ngOnInit() {
    this.fetchCart();
  }

  fetchCart(){
    var customerId = JSON.parse(localStorage.getItem("user"))["id"];
    this.cartService.getCart(customerId).subscribe(
      res=>{console.log(res);
        this.itemList = res
      },err=>{console.log(err)}
    )
  }

}
