import { NgModule } from '@angular/core';
import {  MatButtonModule } from '@angular/material';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatCardModule } from '@angular/material/card';
import {MatGridListModule} from '@angular/material/grid-list';
import {MatIconModule,MatMenuModule} from '@angular/material';
import {MatListModule} from '@angular/material/list';
import { MatBadgeModule, MatSidenavModule } from '@angular/material'
import {MatSnackBarModule} from '@angular/material/snack-bar';
import {
  MatInputModule, MatTableModule,
  MatProgressSpinnerModule,
  MatDatepicker, MatCheckbox, MatRadioButton, MatNativeDateModule, MatDatepickerModule,
  MatCheckboxModule, MatFormFieldModule, MatRadioModule
} from '@angular/material';
import {MatStepperModule} from '@angular/material/stepper';
import {MatSelectModule} from '@angular/material/select';

@NgModule({
  imports: [
    MatButtonModule,
    MatToolbarModule,
    MatCardModule,
    MatIconModule,
    MatMenuModule,
    MatGridListModule,
    MatListModule,
    MatBadgeModule, MatSidenavModule,
    MatInputModule,
    MatStepperModule,
    MatSelectModule,
    MatDatepickerModule,
    MatRadioModule,
    MatNativeDateModule,
    MatSnackBarModule
  ],
  exports:[
    MatButtonModule,
    MatToolbarModule,
    MatCardModule,
    MatIconModule,
    MatMenuModule,
    MatGridListModule,
    MatListModule,
    MatBadgeModule, MatSidenavModule,
    MatInputModule,
    MatStepperModule,
    MatSelectModule,
    MatDatepickerModule,
    MatRadioModule,
    MatNativeDateModule,
    MatSnackBarModule
  ]
})
export class MaterialModule { }
