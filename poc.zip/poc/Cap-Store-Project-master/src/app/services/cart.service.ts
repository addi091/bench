import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Cart } from '../models/CartModel';
import { Product } from '../models/Product';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  baseHref = 'http://localhost:8888';
  constructor(private http: HttpClient) { }

  getCart(customerId: number) {
    return this.http.get<Cart>(this.baseHref + "/cart/" + customerId);
  }

  postCart(customerId: number, productId: number) {
    return this.http.post<Cart>(this.baseHref + "/cart/add/" + customerId + "/" + productId + "/1", {});
  }

  deleteCart(customerId: number) {
    return this.http.delete(this.baseHref + "/cart/" + customerId);
  }

  getWishList() {
    return this.http.get<Product[]>(this.baseHref + "/wishlist/get/" + JSON.parse(localStorage.getItem("user"))["id"]);
  }

  postWishlist(prodId: number) {
    return this.http.post<string>(this.baseHref + "/wishlist/addWish/" + JSON.parse(localStorage.getItem("user"))["id"] + "/" + prodId, {});
  }
}
