import { Category } from './models/Category';
import { ProductService } from './services/product.service';
import { Component, OnInit } from '@angular/core';
import { ServiceService } from './services/service.service';
import { Customer } from './models/customerpage';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  title = 'CapStore';
  category:Category[]=[]
  constructor(public service: ServiceService,private ps:ProductService,private router:Router) { }

  ngOnInit() {
    if (localStorage.getItem("user") != null) {
      this.service.loggedCustomer = JSON.parse(localStorage.getItem("user"));
      this.service.isLogged = true;
    }

    this.ps.getAllCategory().subscribe(
      res=>{
          this.category = res;
      },err=>{console.log(err)}
    )
  }

  logout() {
    localStorage.removeItem("user");
    this.service.loggedCustomer = new Customer();
    this.service.isLogged = false;
    this.router.navigate(['/']);
  }

}