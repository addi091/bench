import { Injectable } from '@angular/core';
import { Registration } from './model/registration';
import { Login } from './model/login';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { book } from './model/book';
import { magazine } from './model/magazine';
import { dvd } from './model/dvd';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {
login = new Login();
receivedObj: Registration;
bookArr: book[];
dvdArr: dvd[];
magArr: magazine[];
baseHref = 'http://localhost:8880';
  constructor(private http: HttpClient, private routes: Router) {
    this.bookArr = [];
  }
  postOne(login: Login) {
    return this.http.post<Login>(this.baseHref + '/login', login);
  }
  registerDetails(register: Registration) {
    return this.http.post<Login>(this.baseHref + '/register', register);
  }
  storeDetails(obj: Registration): any {
    this.receivedObj = obj;
  }
  bookDetails() {
    return this.http.get<book[]>(this.baseHref+'/all');
  }
  dvdDetails() {
    return this.http.get<dvd[]>(this.baseHref+'/all');
  }
  magazineDetails() {
    return this.http.get<magazine[]>(this.baseHref+'/all');
  }


}
