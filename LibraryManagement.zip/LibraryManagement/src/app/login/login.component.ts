import { Component, OnInit } from '@angular/core';
import { Login } from '../model/login';
import { Validators, FormControl } from '@angular/forms';
import { ServiceService } from '../service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  inputEmail: string;

  conversionEncryptOutput: string;

  login = new Login();

  constructor(private service: ServiceService, private router: Router) {}
  hide = true;
  email = new FormControl("", [Validators.required, Validators.email]);

  ngOnInit() {}
  getErrorMessage() {
    return this.email.hasError("required")
      ? "You must enter a value"
      : this.email.hasError("email")
      ? "Not a valid email"
      : "";
  }
  loginn() {
    console.log("login");
  }

  encryptPassword() {
    /*this.conversionEncryptOutput = CryptoJS.AES.encrypt(
      this.logon.password.trim(),
      this.logon.email.trim()
    ).toString();*/
    // this.conversionEncryptOutput = sha1(this.login.password);
    this.login.password = this.conversionEncryptOutput;

    this.router.navigate(["/"]);
  }

  addOneUser() {
    this.service.postOne(this.login).subscribe(
      result => {
        console.log(result);
        console.log("Added Successfully");
      },
      error => {
        console.log(error);
      }
    );
  }
}
