import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material';
import { ServiceService } from '../service.service';
import { magazine } from '../model/magazine';

@Component({
  selector: 'app-magazine',
  templateUrl: './magazine.component.html',
  styleUrls: ['./magazine.component.css']
})
export class MagazineComponent implements OnInit {

  displayedColumns =['magNo', 'magazineTitle', 'noOfCopiesActual', 'noOfCopiesCurrent'];
  dataSource;
  magArr: magazine[] = [];
  mag1: magazine;
  mag2: magazine;
  mag3: magazine;
  resultTrue = false;

  constructor(private serviceService: ServiceService) { }

  ngOnInit() {
    this.getAll();


    this.mag1 = new magazine();
    this.mag2 = new magazine();
    this.mag3 = new magazine();

    this.mag1.magNo = 25;
    this.mag1.magazineTitle = 'JAVA Magazine';
    this.mag1.noOfCopiesActual = 5;
    this.mag1.noOfCopiesCurrent = 3;

    this.mag2.magNo = 26;
    this.mag2.magazineTitle = 'Oracle Magazine';
    this.mag2.noOfCopiesActual = 7;
    this.mag2.noOfCopiesCurrent = 5;

    this.mag3.magNo = 27;
    this.mag3.magazineTitle = 'Angular 7 Magazine';
    this.mag3.noOfCopiesActual = 12;
    this.mag3.noOfCopiesCurrent = 10;

    this.magArr.push(this.mag1);
    this.magArr.push(this.mag2);
    this.magArr.push(this.mag3);
}
getAll() {
  console.log(this.magArr);
  this.serviceService.bookDetails()
  this.dataSource = new MatTableDataSource(this.magArr);

}

}
