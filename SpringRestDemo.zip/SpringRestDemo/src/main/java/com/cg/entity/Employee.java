/**
 * 
 */
package com.cg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Aditya Sinha
 * @version 1.0 This is the POJO class.
 */

@Entity
@Table(name = "employee_details")
public class Employee {

	// ----------Attributes------------
	@Id
	@GeneratedValue
	@Column(name = "id")
	private int empId;

	@Column(name = "emp_name")
	private String empName;

	@Column(name = "bu_name")
	private String buName;

	@Column(name = "salarry")
	private double salary;

	// ------getters & setters-----------

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getBuName() {
		return buName;
	}

	public void setBuName(String buName) {
		this.buName = buName;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	// --------default constructor------
	public Employee() {
	}

	// --------parameterised constructor--------
	public Employee(int empId, String empName, String buName, double salary) {
		this.empId = empId;
		this.empName = empName;
		this.buName = buName;
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName
				+ ", buName=" + buName + ", salary=" + salary + "]";
	}

}
