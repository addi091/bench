/**
 * 
 */
package com.cg.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Employee;
import com.cg.service.EmployeeService;

/**
 * @author Aditya Sinha
 * @version 1.0 This is the RestController class.
 *
 */
@RestController
@RequestMapping("/employee")
public class EmployeeController {

	// -------Injecting the Service interface-------
	@Autowired
	private EmployeeService service;

	/*
	 * This method is to Print the welcome message.
	 */
	@RequestMapping("/hi")
	public String sayHello() {
		return "Hi, Welcome to Company database..";
	}

	/*
	 * This method is to add the Employees details.
	 */
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public Employee addEmployees(@RequestBody Employee employee) {
		service.addEmployee(employee);
		return employee;
	}

	/*
	 * This method is to fetch all the Employee List.
	 */
	@RequestMapping(value = "/all", method = RequestMethod.GET)
	public List<Employee> getAllEmployees() {
		Employee e = new Employee();
		e.getEmpId();
		e.getEmpName();
		e.getBuName();
		e.getSalary();
		return service.getAll();

	}

	/*
	 * This method is to delete the Employee details.
	 */
	@RequestMapping(value = "/delete/{id}", method = RequestMethod.DELETE)
	public String deleteById(@PathVariable("id") int id) {
		service.deleteById(id);
		return "Deleted Sucessfully";
	}

	/*
	 * This method is to fetch the Employee details via Employee ID.
	 */
	@RequestMapping(value = "/employee", method = RequestMethod.GET)
	public Employee getemployee(@RequestParam("empId") int empId) {
		Employee e = service.get(empId);
		return e;
	}

	/*
	 * This method is to update the Employee details via Employee ID.
	 */
	@RequestMapping(value = "/update/{empId}", method = RequestMethod.PUT, produces = "application/json")
	public String updateEmployee(@RequestBody Employee employee,
			@PathVariable("empId") int empId) {
		service.update(employee, empId);
		return "Updated sucessfully";
	}
}
