/**
 * 
 */
package com.cg.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Employee;

/**
 * @author Aditya Sinha
 * @version 1.0 This is the Service Class.
 *
 */
@Service
public class EmployeeServiceJPAImpl implements EmployeeService {

	@PersistenceContext(unitName = "SpringJPA")
	private EntityManager em;

	/*
	 * This method is to add the Employees details.
	 */
	@Transactional
	public void addEmployee(Employee employee) {
		em.persist(employee);

	}

	/*
	 * This method is to fetch all the Employee List.
	 */
	@Transactional
	public List<Employee> getAll() {
		return em.createQuery("from Employee").getResultList();
	}

	/*
	 * This method is to delete the Employee details.
	 */
	@Transactional
	public void deleteById(int id) {
		Employee e = get(id);
		em.remove(e);
	}

	/*
	 * This method is to fetch the Employee details via Employee ID.
	 */
	@Transactional
	public Employee get(int empId) {
		return em.find(Employee.class, empId);
	}

	/*
	 * This method is to update the Employee details via Employee ID.
	 */
	@Transactional
	public Employee update(Employee employee, int empId) {
		employee.setEmpId(empId);
		em.merge(employee);
		return employee;
	}

}
