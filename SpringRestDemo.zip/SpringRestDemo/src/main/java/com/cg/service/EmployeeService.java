/**
 * 
 */
package com.cg.service;

import java.util.List;

import com.cg.entity.Employee;

/**
 * @author Aditya Sinha
 * @version 1.0 This is the service interface.
 *
 */
public interface EmployeeService {
	
	public void addEmployee(Employee employee);

	public List<Employee> getAll();

	public void deleteById(int id);

	public Employee update(Employee employee, int empId);

	public Employee get(int empId);

}
