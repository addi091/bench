/**
 * 
 */
package com.cg.repo;

import org.springframework.data.repository.CrudRepository;

import com.cg.entity.Employee;

/**
 * @author Aditya Sinha
 * @version 1.0 This is the Repository Interface
 */

public interface EmployeeRepo extends CrudRepository<Employee, Integer> {

}
